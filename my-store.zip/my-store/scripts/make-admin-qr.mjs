// scripts/make-admin-qr.mjs
import speakeasy from "speakeasy";
import qrcode from "qrcode";

const secret = process.env.ADMIN_TOTP_SECRET || speakeasy.generateSecret({ length: 20 }).base32;
const otpauth = speakeasy.otpauthURL({ secret, label: "MyStore Admin", encoding: "base32" });

qrcode.toString(otpauth, { type: "terminal" }, (err, out) => {
  if (err) throw err;
  console.log("Scan this QR code in Google Authenticator:\n");
  console.log(out);
  console.log("\nOr add this secret manually:", secret);
});
