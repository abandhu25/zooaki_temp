"use client";

import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";

interface Member {
  id: string;
  position: string;
  permissions: string[];
  user: { name: string; email: string };
}

export default function AdminBODManager() {
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBOD();
  }, []);

  const fetchBOD = async () => {
    const res = await fetch("/api/admin/bod");
    const data = await res.json();
    setMembers(data);
    setLoading(false);
  };

  const removeMember = async (id: string) => {
    if (!confirm("Remove this BOD member?")) return;
    await fetch(`/api/admin/bod?id=${id}`, { method: "DELETE" });
    fetchBOD();
  };

  if (loading) return <p>Loading Board Members...</p>;

  return (
    <div className="mt-10 space-y-6">
      <h2 className="text-2xl font-bold">👥 Board of Directors</h2>
      <p className="text-sm text-gray-500">
        Manage high-level administrative members under your leadership.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {members.map((m) => (
          <Card key={m.id} className="border shadow-sm">
            <CardContent className="p-4">
              <h3 className="font-semibold">{m.user.name}</h3>
              <p className="text-sm text-gray-500">{m.user.email}</p>
              <p className="text-sm mt-2">
                Position: <strong>{m.position}</strong>
              </p>
              <p className="text-xs mt-1">
                Permissions: {m.permissions.join(", ") || "None"}
              </p>

              <button
                onClick={() => removeMember(m.id)}
                className="mt-3 px-3 py-1 bg-red-500 text-white rounded text-sm hover:bg-red-600"
              >
                Remove
              </button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
