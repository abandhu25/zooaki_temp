// /components/FeatureGate.tsx
"use client";

import React from "react";

export default function FeatureGate({
  enabled,
  children,
  fallback,
}: {
  enabled: boolean;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}) {
  if (!enabled) return fallback ?? <div className="rounded-lg border p-4 text-sm text-muted-foreground">Feature paused by admin</div>;
  return <>{children}</>;
}
