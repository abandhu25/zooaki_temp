// components/NotificationsClient.tsx
"use client";
import { useEffect } from "react";
import Pusher from "pusher-js";
import { toast } from "react-hot-toast";

export default function NotificationsClient({ userId }: { userId: string }) {
  useEffect(() => {
    const pusher = new Pusher(process.env.NEXT_PUBLIC_PUSHER_KEY!, {
      cluster: "ap2",
    });

    const channel = pusher.subscribe(`user-${userId}`);
    channel.bind("new-notification", (data: { message: string }) => {
      toast.success(data.message);
    });

    return () => {
      pusher.unsubscribe(`user-${userId}`);
    };
  }, [userId]);

  return null;
}
