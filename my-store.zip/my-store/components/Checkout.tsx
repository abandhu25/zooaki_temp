// components/Checkout.tsx
"use client";
import { useState } from "react";
interface CheckoutProps {
  orderId: string;
  amount: number;
}

export default function Checkout({ cart }: { cart: CheckoutProps[] }) {
  const [loading, setLoading] = useState(false);

  async function handleCheckout() {
    setLoading(true);
    const res = await fetch("/api/orders/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ items: cart }),
    });
    const data = await res.json();
    setLoading(false);
    alert("Order placed: " + data.orderId);
  }

  return (
    <button
      onClick={handleCheckout}
      disabled={loading}
      className="bg-green-500 text-white px-4 py-2 rounded mt-4"
    >
      {loading ? "Processing..." : "Checkout"}
    </button>
  );
}

