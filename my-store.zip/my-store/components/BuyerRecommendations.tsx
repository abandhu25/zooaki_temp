"use client";

import React, { useEffect, useState } from "react";
import { getSmartRecommendations } from "@/lib/ai/recommendations";

interface BuyerRecommendationsProps {
  serverData?: { id: number; name: string }[]; // data passed from server
}

export default function BuyerRecommendations({ serverData }: BuyerRecommendationsProps) {
  const [recs, setRecs] = useState<{ id: number; name: string }[]>(serverData || []);
  const [loading, setLoading] = useState(!serverData?.length);
  const [error, setError] = useState<string | null>(null);

  // Client-side enhancement: fetch latest recs if not preloaded
  useEffect(() => {
    const load = async () => {
      try {
        const data = await getSmartRecommendations("current_user");
        setRecs(data);
      } catch (err) {
        console.error("Recommendation fetch failed:", err);
        setError("AI recommendation system temporarily unavailable.");
      } finally {
        setLoading(false);
      }
    };

    if (!serverData?.length) load();
  }, [serverData]);

  // Loading / fallback state
  if (loading) {
    return (
      <div className="text-sm text-muted-foreground">
        Loading personalized recommendations...
      </div>
    );
  }

  // Error or empty fallback
  if (error || recs.length === 0) {
    return (
      <div className="text-sm text-muted-foreground">
        {error || "No AI recommendations available right now. Check back soon!"}
      </div>
    );
  }

  // Final render
  return (
    <div className="grid gap-3">
      {recs.map((r) => (
        <div
          key={r.id}
          className="border rounded-lg p-4 bg-white dark:bg-gray-900 hover:shadow-md transition"
        >
          <h4 className="font-medium">{r.name}</h4>
          <p className="text-xs text-muted-foreground">AI-picked based on your activity</p>
        </div>
      ))}
    </div>
  );
}
