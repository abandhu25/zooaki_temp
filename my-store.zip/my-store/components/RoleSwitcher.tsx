"use client";

import React from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";

export default function RoleSwitcher() {
  const { data: session } = useSession();
  const router = useRouter();

  if (!session) return null;

  const roles: string[] = session.user.roles || [];

  return (
    <div className="p-4 border rounded-lg">
      <p className="mb-2 text-sm text-muted-foreground">
        Roles available: {roles.join(", ")}
      </p>

      <div className="flex gap-2">
        {roles.includes("buyer") && (
          <button
            className="px-3 py-1 rounded bg-primary text-white hover:opacity-90"
            onClick={() => router.push("/buyer/dashboard")}
          >
            Go to Buyer Dashboard
          </button>
        )}

        {roles.includes("seller") && (
          <button
            className="px-3 py-1 rounded bg-secondary text-white hover:opacity-90"
            onClick={() => router.push("/seller/dashboard")}
          >
            Go to Seller Dashboard
          </button>
        )}
      </div>
    </div>
  );
}
