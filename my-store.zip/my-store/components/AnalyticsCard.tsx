import React from "react";

type Props = { title: string; value: string };

export default function AnalyticsCard({ title, value }: Props) {
  return (
    <div className="border rounded-lg p-4 shadow-sm bg-white dark:bg-gray-900">
      <h3 className="text-sm text-muted-foreground">{title}</h3>
      <p className="text-xl font-semibold mt-1">{value}</p>
    </div>
  );
}
