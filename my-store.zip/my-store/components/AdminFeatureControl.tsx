"use client";

import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";

interface Feature {
  id: string;
  name: string;
  isEnabled: boolean;
  route: string;
}

export default function AdminFeatureControl() {
  const [features, setFeatures] = useState<Feature[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFeatures();
  }, []);

  const fetchFeatures = async () => {
    try {
      const res = await fetch("/api/admin/features");
      const data = await res.json();
      setFeatures(data);
    } catch (err) {
      console.error("Failed to load features:", err);
    } finally {
      setLoading(false);
    }
  };

  const toggleFeature = async (name: string, enabled: boolean) => {
    try {
      await fetch("/api/admin/features", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, enabled }),
      });
      fetchFeatures(); // refresh after update
    } catch (err) {
      console.error("Toggle failed:", err);
    }
  };

  const deleteFeature = async (name: string) => {
    if (!confirm(`Delete feature "${name}"? This cannot be undone.`)) return;
    try {
      await fetch(`/api/admin/features?name=${encodeURIComponent(name)}`, {
        method: "DELETE",
      });
      fetchFeatures();
    } catch (err) {
      console.error("Delete failed:", err);
    }
  };

  if (loading) return <p>Loading Founder Controls...</p>;

  return (
    <div className="mt-10 space-y-6">
      <h2 className="text-2xl font-bold">🧩 Founder Controls</h2>
      <p className="text-gray-500 text-sm">
        Toggle, pause, or delete features across ZooAki — changes apply globally.
      </p>

      {features.length === 0 ? (
        <p className="text-sm text-muted-foreground">No features found.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map((f) => (
            <Card key={f.id} className="border shadow-sm hover:shadow-lg transition-all">
              <CardContent className="p-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-semibold">{f.name}</h3>
                  <span
                    className={`px-2 py-1 rounded-full text-xs font-medium ${
                      f.isEnabled ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                    }`}
                  >
                    {f.isEnabled ? "Enabled" : "Disabled"}
                  </span>
                </div>
                <p className="text-xs text-gray-500 mb-4">Route: {f.route}</p>

                <div className="flex gap-2">
                  <button
                    onClick={() => toggleFeature(f.name, !f.isEnabled)}
                    className={`px-3 py-1 rounded text-sm font-medium ${
                      f.isEnabled
                        ? "bg-yellow-500 hover:bg-yellow-600 text-white"
                        : "bg-green-600 hover:bg-green-700 text-white"
                    }`}
                  >
                    {f.isEnabled ? "Pause" : "Launch"}
                  </button>

                  <button
                    onClick={() => deleteFeature(f.name)}
                    className="px-3 py-1 rounded bg-red-500 hover:bg-red-600 text-white text-sm font-medium"
                  >
                    Delete
                  </button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
