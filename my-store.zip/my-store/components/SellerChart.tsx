"use client";

import React from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export default function SellerChart({ data }: { data: Record<string, number> }) {
  const chartData = Object.entries(data).map(([month, value]) => ({
    month,
    value,
  }));

  return (
    <div className="border rounded-lg p-4 bg-white dark:bg-gray-900 shadow-sm">
      <h2 className="text-lg font-medium mb-3">Monthly Sales Overview</h2>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={chartData}>
          <XAxis dataKey="month" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="value" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
