// app/orders/api/page.tsx
"use client";
import { Order } from "@prisma/client";
import { useEffect, useState } from "react";

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    fetch("/api/orders").then(res => res.json()).then(setOrders);
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">My Orders</h1>
      <ul className="mt-4">
        {orders.map(order => (
          <li key={order.id} className="border p-2 mb-2">
            Order #{order.id} - {order.status} - ₹{order.amount}
          </li>
        ))}
      </ul>
    </div>
  );
}

