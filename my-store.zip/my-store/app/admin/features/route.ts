import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { hasPower } from "@/lib/acl";

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);

  if (!hasPower(session, "FOUNDER_ONLY")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { name, enabled } = await req.json();
  if (!name) return NextResponse.json({ error: "Missing feature name" }, { status: 400 });

  const feature = await prisma.featureControl.upsert({
    where: { name },
    create: { name, isEnabled: enabled, route: `/api/${name}` },
    update: { isEnabled: enabled },
  });

  return NextResponse.json({ ok: true, name, isEnabled: feature.isEnabled });
}
