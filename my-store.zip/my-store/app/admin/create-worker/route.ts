import { NextRequest, NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import prisma from "@/lib/prisma";
import bcrypt from "bcryptjs";

export async function POST(req: NextRequest) {
  try {
    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });

    // 🔒 Only admins or founders can create workers
    if (!token || !token.roles?.includes("ADMIN")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { name, email, password } = body as {
      name?: string;
      email?: string;
      password?: string;
    };

    if (!email || !password) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const createdUser = await prisma.user.create({
      data: {
        name: name ?? null,
        email,
        password: hashedPassword,
        roles: ["WORKER"], // ✅ Worker role
      },
    });

    return NextResponse.json(
      { success: true, userId: createdUser.id },
      { status: 201 }
    );
  } catch (e: unknown) {
  const error = e instanceof Error ? e.message : "Unknown error";
  return NextResponse.json({ error }, { status: 500 });
}
}
