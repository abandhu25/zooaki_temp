"use client";

import React, { useEffect, useState } from "react";
import AdminCreateWorker from "@/components/AdminCreateWorker";
import { useSession, signOut } from "next-auth/react";

type Feature = {
  name: string;
  isEnabled: boolean;
  route: string;
};

export default function AdminDashboard() {
  const { data: session } = useSession();
  const [features, setFeatures] = useState<Feature[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchFeatures();
  }, []);

  const fetchFeatures = async (): Promise<void> => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/features", { method: "GET" });
      if (!res.ok) throw new Error("Failed to load features");
      const data = (await res.json()) as { features: Feature[] };
      setFeatures(data.features || []);
    } catch (err) {
      if (err instanceof Error) setError(err.message);
      else setError("An unknown error occurred");
    } finally {
      setLoading(false);
    }
  };

  const toggleFeature = async (name: string, enabled: boolean, route: string): Promise<void> => {
    try {
      const res = await fetch("/api/admin/features", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, enabled, route }),
      });
      if (!res.ok) throw new Error("Failed to update feature");
      await fetchFeatures();
    } catch (err) {
      console.error(err);
    }
  };

  if (!session) return <p>Loading session...</p>;

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-semibold">
        Welcome, {session.user.name || "Admin"}
      </h1>
      <p className="text-sm text-muted-foreground">
        You can toggle features and manage workers here.
      </p>

      {/* 🧩 Features Section */}
      <section className="rounded-lg border p-4">
        <h2 className="text-lg font-medium mb-3">Feature Toggles</h2>

        {loading && <p>Loading features...</p>}
        {error && <p className="text-red-500">{error}</p>}

        <ul className="space-y-2">
          {features.map((f) => (
            <li
              key={f.name}
              className="flex justify-between items-center border-b py-2"
            >
              <div>
                <p className="font-medium">{f.name}</p>
                <p className="text-xs text-muted-foreground">{f.route}</p>
              </div>
              <button
                className={`px-3 py-1 rounded text-sm ${
                  f.isEnabled ? "bg-green-500" : "bg-red-500"
                } text-white`}
                onClick={() => toggleFeature(f.name, !f.isEnabled, f.route)}
              >
                {f.isEnabled ? "Disable" : "Enable"}
              </button>
            </li>
          ))}
        </ul>
      </section>

      {/* 🧑‍🏭 Worker Creation */}
      <section className="rounded-lg border p-4">
        <h2 className="text-lg font-medium mb-3">Create Worker Account</h2>
        <form
          action="/api/admin/create-worker"
          method="POST"
          className="flex flex-col gap-2"
        >
          <input
            type="text"
            name="name"
            placeholder="Worker Name"
            required
            className="border rounded p-2"
          />
          <input
            type="email"
            name="email"
            placeholder="Worker Email"
            required
            className="border rounded p-2"
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            required
            className="border rounded p-2"
          />
          <button
            type="submit"
            className="px-3 py-2 rounded bg-primary text-white hover:opacity-90"
          >
            Create Worker
          </button>
        </form>
      </section>

      {/* 🔗 Quick Links */}
      <section className="rounded-lg border p-4">
        <h2 className="text-lg font-medium mb-3">Quick Links</h2>
        <ul className="list-disc list-inside text-sm space-y-1">
          <li>
            <a href="/buyer" className="underline">
              View Buyers
            </a>
          </li>
          <li>
            <a href="/seller" className="underline">
              View Sellers
            </a>
          </li>
          <li>
            <a href="/worker" className="underline">
              View Workers
            </a>
          </li>
        </ul>
      </section>

      {/* 🚪 Logout */}
      <button
        onClick={() => signOut({ callbackUrl: "/" })}
        className="px-3 py-2 rounded bg-red-500 text-white hover:opacity-90"
      >
        Logout
      </button>
      <div className="mt-10">
    <AdminCreateWorker />
    </div>
    </div>
  );
}
