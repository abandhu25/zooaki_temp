"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Card, CardContent } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import AdminFeatureControl from "@/components/AdminFeatureControl";
import AdminBODManager from "@/components/AdminBODManager";

interface MetricsData {
  system: { userCount: number; petCount: number; orderCount: number };
  features: { total: number; active: number };
  ai: { recommendationAccuracy: number; avgResponseTime: string; lastModelUpdate: string };
  financials: { totalRevenue: number; avgOrderValue: number; refunds: number };
  lastSync: string;
}

export default function AdminMonitoringPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [metrics, setMetrics] = useState<MetricsData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Redirect if not founder
    if (status === "authenticated" && !session?.user.roles?.includes("FOUNDER")) {
      router.push("/"); // Redirect to home if not founder
      return;
    }

    if (status === "authenticated" && session?.user.roles?.includes("FOUNDER")) {
      fetchMetrics();
    }
    // ✅ Added router as dependency to satisfy ESLint
  }, [status, session, router]);

  const fetchMetrics = async () => {
    try {
      const res = await fetch("/api/admin/metrics");
      const data = await res.json();
      setMetrics(data);
    } catch (err) {
      console.error("Metrics fetch failed:", err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="p-8 text-lg">Loading analytics...</div>;

  if (!metrics)
    return (
      <div className="p-8 text-lg text-red-500">
        Failed to load metrics or you don’t have permission.
      </div>
    );

  const systemData = [
    { name: "Users", value: metrics.system.userCount },
    { name: "Pets", value: metrics.system.petCount },
    { name: "Orders", value: metrics.system.orderCount },
  ];

  const featureData = [
    { name: "Active", value: metrics.features.active },
    { name: "Total", value: metrics.features.total },
  ];

  return (
    <div className="p-8 space-y-8">
      <h1 className="text-3xl font-bold">📊 ZooAki Control Center</h1>
      <p className="text-sm text-gray-500">
        Last Synced: {new Date(metrics.lastSync).toLocaleString()}
      </p>

      {/* System Overview */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="shadow-lg border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-2">👥 Total Users</h3>
            <p className="text-3xl font-bold">{metrics.system.userCount}</p>
          </CardContent>
        </Card>

        <Card className="shadow-lg border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-2">🐾 Pets Registered</h3>
            <p className="text-3xl font-bold">{metrics.system.petCount}</p>
          </CardContent>
        </Card>

        <Card className="shadow-lg border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-2">🛒 Orders</h3>
            <p className="text-3xl font-bold">{metrics.system.orderCount}</p>
          </CardContent>
        </Card>
      </section>

      {/* Financial Stats */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="shadow-lg border bg-green-50">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-2">💰 Total Revenue</h3>
            <p className="text-3xl font-bold">₹{metrics.financials.totalRevenue.toLocaleString()}</p>
          </CardContent>
        </Card>

        <Card className="shadow-lg border bg-yellow-50">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-2">📦 Avg Order Value</h3>
            <p className="text-3xl font-bold">₹{metrics.financials.avgOrderValue}</p>
          </CardContent>
        </Card>

        <Card className="shadow-lg border bg-red-50">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-2">↩️ Refunds</h3>
            <p className="text-3xl font-bold">{metrics.financials.refunds}</p>
          </CardContent>
        </Card>
      </section>

      {/* Charts */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="shadow border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">📈 System Overview</h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={systemData}>
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#4f46e5" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="shadow border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">⚙️ Feature Status</h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={featureData}>
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#16a34a" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </section>

      {/* AI Insights */}
      <section className="mt-10">
        <Card className="shadow border bg-blue-50">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-2">🤖 AI Performance</h3>
            <p>Recommendation Accuracy: {metrics.ai.recommendationAccuracy}%</p>
            <p>Average Response Time: {metrics.ai.avgResponseTime}</p>
            <p>Last Model Update: {metrics.ai.lastModelUpdate}</p>
          </CardContent>
        </Card>
      </section>

      <AdminBODManager />
      <AdminFeatureControl />
    </div>
  );
}
