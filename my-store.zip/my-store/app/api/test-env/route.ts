// app/api/test-env/route.ts
import { NextResponse } from "next/server";

export async function GET() {
  console.log("ENV", {
    NEXTAUTH_SECRET: process.env.NEXTAUTH_SECRET,
    RAZORPAY_KEY_ID: process.env.RAZORPAY_KEY_ID,
    RAZORPAY_KEY_SECRET: process.env.RAZORPAY_KEY_SECRET,
    DATABASE_URL: process.env.DATABASE_URL,
  });

  return NextResponse.json({ ok: true });
}
