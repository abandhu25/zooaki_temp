// app/api/payment/verify/route.ts
import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import crypto from "crypto";

export async function POST(req: NextRequest) {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } =
      await req.json();

    const secret = process.env.RAZORPAY_KEY_SECRET!;
    const hmac = crypto
      .createHmac("sha256", secret)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest("hex");

    if (hmac !== razorpay_signature) {
      return NextResponse.json({ error: "Invalid payment signature" }, { status: 400 });
    }

    const payment = await prisma.payment.update({
      where: { providerOrderId: razorpay_order_id },
      data: {
        providerPaymentId: razorpay_payment_id ?? undefined,
        status: "success",
      },
    });

    const order = await prisma.order.update({
      where: { id: payment.orderId! },
      data: { status: "confirmed" },
    });

    await prisma.notification.create({
      data: {
        userId: order.userId,
        type: "ORDER_UPDATE",
        message: `Your order ${order.id} is confirmed.`,
      },
    });

    return NextResponse.json({ success: true });
  } catch (err: unknown) {
    console.error(err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Unknown error" },
      { status: 500 }
    );
  }
}
