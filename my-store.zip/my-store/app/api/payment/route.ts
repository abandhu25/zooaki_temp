// app/api/payment/route.ts
import { NextRequest, NextResponse } from "next/server";
import Razorpay from "razorpay";
import prisma from "@/lib/prisma";
import { getToken } from "next-auth/jwt";
import { PaymentStatus } from "@prisma/client";

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

type CartItem = {
  productId: string;
  quantity: number;
  price: number;
};

type PaymentPayload = {
  amount: number;
  cart: CartItem[];
};

export async function POST(req: NextRequest) {
  try {
    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
    if (!token?.id && !token?.sub) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { amount, cart }: PaymentPayload = await req.json();
    if (!amount || !Array.isArray(cart)) {
      return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
    }

    const userId = token.id ?? token.sub!;
    if (!userId) {
      return NextResponse.json({ error: "Invalid user" }, { status: 400 });
    }

    // Razorpay order creation
    const razorpayOrder = await razorpay.orders.create({
      amount: Math.round(Number(amount) * 100),
      currency: "INR",
      receipt: `rcpt_${Date.now()}`,
    });

    // Create order in DB
    const newOrder = await prisma.order.create({
      data: {
        userId,
        amount: Math.round(Number(amount) * 100),
        status: "created",
        items: {
          create: cart.map((item) => ({
            productId: item.productId,
            quantity: item.quantity,
            price: item.price,
          })),
        },
      },
      include: { items: true },
    });

    // Create payment record
    await prisma.payment.create({
      data: {
        userId,
        orderId: newOrder.id,
        provider: "razorpay",
        providerOrderId: razorpayOrder.id,
        status: "created" as PaymentStatus,
        amount: Math.round(Number(amount) * 100),
      },
    });

    return NextResponse.json({
      orderId: razorpayOrder.id,
      amount: razorpayOrder.amount,
      key: process.env.RAZORPAY_KEY_ID,
      dbOrderId: newOrder.id,
    });
  } catch (error) {
    console.error("Payment route error:", error);
    return NextResponse.json({ error: "Payment initialization failed" }, { status: 500 });
  }
}
