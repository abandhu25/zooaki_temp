import { NextRequest, NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import prisma from "@/lib/prisma";

export async function POST(req: NextRequest) {
  try {
    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
    if (!token?.sub) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = token.sub;
    const { productId } = await req.json();

    const product = await prisma.product.findUnique({ where: { id: productId } });
    if (!product) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    const existing = await prisma.recommendationProfile.findUnique({
      where: { userId },
    });

    const history = (existing?.history as Record<string, unknown>) || {};
    const wishlist: string[] = Array.from(new Set([...(history.wishlist as string[] || []), productId]));

    await prisma.recommendationProfile.upsert({
      where: { userId },
      update: { history: { ...history, wishlist } },
      create: {
        userId,
        preferences: {},
        history: { wishlist: [productId] },
      },
    });

    return NextResponse.json({ success: true, wishlist });
  } catch (err) {
    console.error("Wishlist error:", err);
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
}
