// app/api/products/route.ts
import { NextRequest, NextResponse } from "next/server";
import prisma from "../../../prisma/client"; // adjust path if needed

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export async function GET( req: NextRequest) {
  try {
    const products = await prisma.product.findMany({
      orderBy: { createdAt: "desc" },
      take: 50,
    });
    return NextResponse.json(products);
  } catch (err) {
    if (err instanceof Error) return NextResponse.json({ error: err.message }, { status: 500 });
    return NextResponse.json({ error: "Unknown error" }, { status: 500 });
  }
}
