/* eslint-disable @typescript-eslint/no-unused-vars */
// app/api/orders/webhook/route.ts
import { NextRequest, NextResponse } from "next/server";
import prisma from "../../../../prisma/client";
import crypto from "crypto";

export async function POST(req: NextRequest) {
  try {
    const bodyText = await req.text();
    const sig = req.headers.get("x-razorpay-signature") || "";

    const expected = crypto
      .createHmac("sha256", process.env.RAZORPAY_WEBHOOK_SECRET!)
      .update(bodyText)
      .digest("hex");

    if (sig !== expected) {
      return NextResponse.json({ ok: false, error: "invalid signature" }, { status: 401 });
    }

    const payload = JSON.parse(bodyText);

    if (payload.event === "payment.captured" || payload.event === "payment.authorized") {
      const paymentEntity = payload.payload.payment.entity;
      const rpOrderId = paymentEntity.order_id; // Razorpay order id
      const rpPaymentId = paymentEntity.id; // Razorpay payment id
      const amount = paymentEntity.amount / 100; // convert paise to rupees

      // update payment row by matching Razorpay orderId
      const updated = await prisma.payment.updateMany({
        where: { providerOrderId: rpOrderId },
        data: { providerPaymentId: rpPaymentId, status: "success" as const, amount },
      });

      // If linked to an order, also mark order as paid
      const pay = await prisma.payment.findFirst({ where: { providerPaymentId: rpPaymentId } });
      if (pay && pay.orderId) {
        await prisma.order.update({
          where: { id: pay.orderId },
          data: { status: "success" as const },
        });
      }
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof Error) return NextResponse.json({ error: err.message }, { status: 500 });
    return NextResponse.json({ error: "Unknown error" }, { status: 500 });
  }
}
