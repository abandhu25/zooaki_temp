import { NextRequest, NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import prisma from "@/lib/prisma";
import Razorpay from "razorpay";
import { pusherServer } from "@/lib/pusher"; // <-- add this

if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
  throw new Error("Razorpay environment variables are missing");
}

const razor = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

export async function POST(req: NextRequest) {
  try {
    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
    if (!token?.sub) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = token.sub;
    const { items } = await req.json();

    if (!Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: "No items provided" }, { status: 400 });
    }

    let total = 0;
    const snapshot: { productId: string; quantity: number; price: number }[] = [];

    for (const it of items) {
      const p = await prisma.product.findUnique({ where: { id: String(it.productId) } });
      if (!p) {
        return NextResponse.json({ error: `Product ${it.productId} not found` }, { status: 400 });
      }
      const qty = Number(it.quantity) || 1;
      total += p.price * qty;
      snapshot.push({ productId: p.id, quantity: qty, price: p.price });
    }

    const order = await prisma.order.create({
      data: {
        userId,
        amount: total,
        status: "created",
        items: {
          create: snapshot.map((s) => ({
            productId: s.productId,
            quantity: s.quantity,
            price: s.price,
          })),
        },
      },
      include: { items: true },
    });

    const rOrder = await razor.orders.create({
      amount: total * 100,
      currency: "INR",
      receipt: `order_${order.id}`,
    });

    await prisma.payment.create({
      data: {
        orderId: order.id,
        userId,
        status: "created",
        amount: total,
        providerOrderId: rOrder.id,
      },
    });

    // ✅ Fixed: use userId not user.id
    await prisma.notification.create({
      data: {
        userId,
        type: "order_update",
        message: `Your order #${order.id} has been confirmed!`,
      },
    });

    await pusherServer.trigger(`user-${userId}`, "new-notification", {
      message: `Your order #${order.id} has been confirmed!`,
    });

    return NextResponse.json({ orderId: order.id, razorpayOrder: rOrder });
  } catch (err) {
    console.error("Order create error:", err);
    if (err instanceof Error) {
      return NextResponse.json({ error: err.message }, { status: 500 });
    }
    return NextResponse.json({ error: "Unknown error" }, { status: 500 });
  }
}
