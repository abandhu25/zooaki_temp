// app/api/orders/route.ts
import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getToken } from "next-auth/jwt";

interface OrderItemInput {
  productId: string;
  quantity: number;
  price: number;
}

export async function POST(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { items, totalAmount }: { items: OrderItemInput[]; totalAmount: number } =
    await req.json();

  const order = await prisma.order.create({
    data: {
      userId: token.id,
      amount: totalAmount, // ✅ change "total" → "amount"
      items: {
        create: items.map((i) => ({
          productId: i.productId,
          quantity: i.quantity,
          price: i.price,
        })),
      },
    },
    include: { items: true },
  });

  await prisma.notification.create({
    data: { userId: token.id, message: "✅ Order placed successfully!", type: "order_update" },
  });

  return NextResponse.json(order);
}
