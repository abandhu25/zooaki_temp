import prisma from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import type { Product } from "@prisma/client";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) {
    return new Response("Unauthorized", { status: 401 });
  }

  const profile = await prisma.recommendationProfile.findUnique({
    where: { userId: session.user.id },
  });

  let recommendedProducts: Product[] = [];
  if (profile?.preferences) {
    const topCategories = Object.entries(profile.preferences)
      .sort((a, b) => (b[1] as number) - (a[1] as number))
      .slice(0, 3)
      .map(([cat]) => cat);

    recommendedProducts = await prisma.product.findMany({
      where: { category: { in: topCategories } },
      take: 10,
    });
  }

  return new Response(JSON.stringify(recommendedProducts));
}
