import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getToken } from "next-auth/jwt";
import { Role } from "@prisma/client";

export async function POST(req: NextRequest) {
  try {
    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
    if (!token?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { role } = await req.json();

    const user = await prisma.user.findUnique({
      where: { id: token.id },
      select: { roles: true },
    });

    if (!user?.roles.includes(role as Role)) {
      return NextResponse.json({ error: "Invalid role" }, { status: 400 });
    }

    await prisma.user.update({
      where: { id: token.id },
      data: { activeRole: role as Role },
    });

    return NextResponse.json(
      { message: `Active role switched to ${role}` },
      { status: 200 }
    );
  } catch (err) {
    console.error("Switch role error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
