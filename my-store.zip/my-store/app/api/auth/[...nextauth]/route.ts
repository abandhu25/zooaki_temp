// app/api/auth/[...nextauth]/route.ts
import type { NextAuthOptions, Session, User } from "next-auth";
import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import GoogleProvider from "next-auth/providers/google";
import type { AdapterUser } from "next-auth/adapters";
import type { Account, Profile } from "next-auth";
import { JWT } from "next-auth/jwt";

import bcrypt from "bcryptjs";
import prisma from "@/lib/prisma";

// Helper type (no 'any') for a user record that includes roles/activeRole
type UserWithRoles = (User | AdapterUser) & {
  id: string;
  roles?: string[];
  activeRole?: string | null;
};

export const authOptions: NextAuthOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID ?? "",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? "",
    }),
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials.password) return null;

        const user = await prisma.user.findUnique({
          where: { email: credentials.email },
        });
        if (!user) return null;

        const ok = await bcrypt.compare(credentials.password, user.password);
        if (!ok) return null;

        // This conforms to our augmented `User` type (roles/activeRole)
        return {
          id: user.id,
          name: user.name,
          email: user.email,
          roles: user.roles ?? [],
          activeRole: user.activeRole ?? null,
        } satisfies UserWithRoles;
      },
    }),
  ],

  session: {
    strategy: "jwt",
  },

  callbacks: {
    async jwt(params: {
      token: JWT;
      user?: User | AdapterUser | null;
      account?: Account | null;
      profile?: Profile;
      trigger?: "signIn" | "signUp" | "update";
      isNewUser?: boolean;
      session?: Session;
    }): Promise<JWT> {
      const { token, user } = params;

      if (user) {
        const u = user as UserWithRoles;
        token.id = u.id;
        token.roles = u.roles ?? [];
        token.activeRole = u.activeRole ?? null;
      }
      return token;
    },

    async session(params: {
      session: Session;
      token: JWT;
      user: AdapterUser;
      newSession?: Session;
      trigger?: "update";
    }): Promise<Session> {
      const { session, token } = params;

      if (session.user) {
        session.user.id = (token.id ?? "") as string;
        session.user.roles = (token.roles ?? []) as string[];
        session.user.activeRole = (token.activeRole ?? null) as string | null;
      }
      return session;
    },
  },

  pages: {
    signIn: "/login",
    error: "/auth/error",
  },

  secret: process.env.NEXTAUTH_SECRET,
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };
