import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getToken } from "next-auth/jwt";
import { JWT } from "next-auth/jwt"; // ✅ Explicitly import JWT type
import { hasPower } from "@/lib/acl"; // Assuming you’ve defined this

export async function GET(req: NextRequest) {
  const token = (await getToken({ req, secret: process.env.NEXTAUTH_SECRET })) as JWT;
  if (!token || !hasPower(token, "FOUNDER_ONLY")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const members = await prisma.boardMember.findMany({
    include: { user: { select: { name: true, email: true } } },
  });
  return NextResponse.json(members);
}

export async function POST(req: NextRequest) {
  const token = (await getToken({ req, secret: process.env.NEXTAUTH_SECRET })) as JWT;
  if (!token || !hasPower(token, "FOUNDER_ONLY")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { userId, position, permissions } = await req.json();

  const member = await prisma.boardMember.create({
    data: { userId, position, permissions },
  });

  return NextResponse.json({ success: true, member });
}

export async function DELETE(req: NextRequest) {
  const token = (await getToken({ req, secret: process.env.NEXTAUTH_SECRET })) as JWT;
  if (!token || !hasPower(token, "FOUNDER_ONLY")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "Missing ID" }, { status: 400 });

  await prisma.boardMember.delete({ where: { id } });
  return NextResponse.json({ success: true });
}
