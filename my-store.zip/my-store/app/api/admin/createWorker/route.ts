import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import bcrypt from "bcryptjs";
import { Role } from "@prisma/client";

export async function POST(req: NextRequest) {
  try {
    const { name, email, password } = await req.json();

    if (!name || !email || !password) {
      return NextResponse.json(
        { error: "All fields are required" },
        { status: 400 }
      );
    }

    const existingUser = await prisma.user.findUnique({ where: { email } });
    if (existingUser) {
      return NextResponse.json({ error: "User already exists" }, { status: 400 });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newWorker = await prisma.user.create({
      data: {
        name,
        email,
        password: hashedPassword,
        roles: [Role.WORKER],
        activeRole: Role.WORKER,
      },
    });

    return NextResponse.json(
      { message: "Worker created successfully", worker: newWorker },
      { status: 201 }
    );
  } catch (err) {
    console.error("Error creating worker:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
