import { NextResponse, type NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getToken } from "next-auth/jwt";

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;

  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token?.id && !token?.sub) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const ownerId = token.id ?? token.sub;

  const pet = await prisma.pet.findFirst({
    where: { id, ownerId },
    include: {
      streaks: true,
      healthEvents: true,
    },
  });

  if (!pet) {
    return NextResponse.json({ error: "Pet not found" }, { status: 404 });
  }

  // Build combined feed from multiple event types
  const feed = [
    ...pet.streaks.map((s) => ({
      type: "STREAK",
      content: `Pet streak posted on ${s.day.toDateString()}`,
      mediaUrl: s.frontUrl ?? s.rearUrl ?? null,
      createdAt: s.postedAt,
    })),
    ...pet.healthEvents.map((e) => ({
      type: "HEALTH",
      content: `${e.kind} logged on ${e.date.toDateString()}`,
      mediaUrl: null,
      createdAt: e.date,
    })),
  ].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

  return NextResponse.json({ pet: pet.name, feed });
}
