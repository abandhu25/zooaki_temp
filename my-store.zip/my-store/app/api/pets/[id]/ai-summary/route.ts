import { NextResponse, type NextRequest } from "next/server";
import OpenAI from "openai";
import prisma from "@/lib/prisma";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY! });

export async function GET(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;

  const pet = await prisma.pet.findUnique({
    where: { id },
    include: { healthEvents: true, pregnancies: true, vetVisits: true },
  });

  if (!pet) {
    return NextResponse.json({ error: "Pet not found" }, { status: 404 });
  }

  const prompt = `Summarize this pet in 5-8 friendly lines for a pet profile.
Name: ${pet.name}
Species: ${pet.species}
Breed: ${pet.breed ?? "Unknown"}
Sex: ${pet.sex ?? "Unknown"}
Notes: ${pet.notes ?? "None"}
Health events count: ${pet.healthEvents.length}
Pregnancy records: ${pet.pregnancies.length}
Vet visits: ${pet.vetVisits.length}`;

  const completion = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.6,
  });

  const summary = completion.choices[0]?.message?.content ?? "No summary.";
  return NextResponse.json({ pet: pet.name, summary });
}
