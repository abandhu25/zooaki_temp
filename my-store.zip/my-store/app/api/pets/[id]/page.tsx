"use client";
import { useEffect, useState } from "react";
import Image from "next/image";
export default function PetFeed({ params }: { params: { id: string } }) {
interface FeedItem {
  id: string;
  type: string;
  content?: string;
  mediaUrl?: string;
  createdAt: string;
}

const [feed, setFeed] = useState<FeedItem[]>([]);


  useEffect(() => {
    fetch(`/api/pets/${params.id}/feed`)
      .then((res) => res.json())
      .then(setFeed);
  }, [params.id]);

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">🐾 Pet Feed</h1>
      {feed.map((item) => (
        <div key={item.id} className="border-b border-gray-300 mb-2 pb-2">
          <p className="text-sm text-gray-600">{item.type}</p>
          <p>{item.content}</p>
          {item.mediaUrl && (
            <Image src={item.mediaUrl} alt="pet" width={200} height={200} className="mt-2 rounded-md" />
          )}
        </div>
      ))}
    </div>
  );
}
