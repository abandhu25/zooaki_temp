import { NextResponse, type NextRequest } from "next/server";
import prisma from "@/lib/prisma";

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;

  const { frontUrl, rearUrl } = body as { frontUrl?: string; rearUrl?: string };

  const now = new Date();
  const day = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  // ensure one streak per day; update if exists
  const existing = await prisma.petStreak.findFirst({ where: { petId: id, day } });

  const streak = existing
    ? await prisma.petStreak.update({
        where: { id: existing.id },
        data: {
          postedAt: now,
          frontUrl: frontUrl ?? existing.frontUrl,
          rearUrl: rearUrl ?? existing.rearUrl,
          late: false,
          skipped: false,
        },
      })
    : await prisma.petStreak.create({
        data: {
          petId: id,
          day,
          postedAt: now,
          frontUrl: frontUrl ?? null,
          rearUrl: rearUrl ?? null,
          late: false,
          skipped: false,
        },
      });

  // Add to feed (optional)
  await prisma.petFeed.create({
    data: {
      petId: id,
      type: "STREAK",
      mediaUrl: frontUrl ?? rearUrl ?? null,
      content: "Daily streak posted",
    },
  });

  // Save media gallery entries
  const toCreate: { petId: string; url: string; source: string }[] = [];
  if (frontUrl) toCreate.push({ petId: id, url: frontUrl, source: "streak" });
  if (rearUrl) toCreate.push({ petId: id, url: rearUrl, source: "streak" });
  if (toCreate.length) await prisma.petMedia.createMany({ data: toCreate });

  return NextResponse.json({ success: true, streak });
}
