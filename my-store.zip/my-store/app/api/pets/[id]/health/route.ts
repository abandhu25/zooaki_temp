import { NextResponse, type NextRequest } from "next/server";
import prisma from "@/lib/prisma";

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;

  const { kind, date, value, notes, attachmentUrls = [] } = body as {
    kind: string;
    date?: string;
    value?: string;
    notes?: string;
    attachmentUrls?: string[];
  };

  if (!kind) {
    return NextResponse.json({ error: "Missing 'kind'." }, { status: 400 });
  }

  // Create health event
  const event = await prisma.petHealthEvent.create({
    data: {
      petId: id,
      kind,
      date: date ? new Date(date) : new Date(),
      value: value ?? null,
      notes: notes ?? null,
    },
  });

  // Optional: attach media records to this event (reverse relation name “PetHealthEventMedia”)
  if (attachmentUrls.length > 0) {
    await prisma.petMedia.createMany({
      data: attachmentUrls.map((url: string) => ({
        petId: id,
        url,
        source: "upload",
        // The relation is on PetHealthEvent.attachments, Prisma links by relation table automatically
        // For simple createMany, we just create media; attaching via join would need manual linking if you modeled a join table.
      })),
    });
  }

  // Add a feed entry
  await prisma.petFeed.create({
    data: {
      petId: id,
      type: "HEALTH",
      content: `${kind}${value ? `: ${value}` : ""}`,
      mediaUrl: Array.isArray(attachmentUrls) && attachmentUrls[0] ? attachmentUrls[0] : null,
    },
  });

  return NextResponse.json(event);
}
