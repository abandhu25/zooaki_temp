import { NextResponse, type NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getToken } from "next-auth/jwt";

//
// 🧩 GET — Fetch Pet Gallery
//
export async function GET(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;

  try {
    const gallery = await prisma.petMedia.findMany({
      where: { petId: id },
      orderBy: { createdAt: "desc" },
    });

    if (!gallery || gallery.length === 0) {
      return NextResponse.json({ message: "No media found." }, { status: 200 });
    }

    return NextResponse.json(gallery);
  } catch (err) {
    console.error("🐾 Gallery fetch error:", err);
    return NextResponse.json(
      { error: "Failed to fetch gallery." },
      { status: 500 }
    );
  }
}

//
// 🧩 POST — Upload Pet Media
//
export async function POST(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;

  try {
    const token = await getToken({
      req: request,
      secret: process.env.NEXTAUTH_SECRET,
    });
    if (!token?.id && !token?.sub) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { url, source, meta } = body as {
      url: string;
      source?: string;
      meta?: unknown;
    };

    if (!url) {
      return NextResponse.json({ error: "Missing image URL" }, { status: 400 });
    }

    // Create Pet Media entry
    const media = await prisma.petMedia.create({
      data: {
        petId: id,
        url,
        source: source || "upload",
        meta: meta ?? {},
      },
    });

    // Automatically add to feed
    await prisma.petFeed.create({
      data: {
        petId: id,
        type: "GALLERY",
        content: "New pet photo added 📸",
        mediaUrl: url,
      },
    });

    return NextResponse.json(media);
  } catch (err) {
    console.error("🐾 Gallery upload error:", err);
    return NextResponse.json(
      { error: "Failed to upload image" },
      { status: 500 }
    );
  }
}
