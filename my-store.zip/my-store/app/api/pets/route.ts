import { NextResponse, type NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getToken } from "next-auth/jwt";

export async function GET(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token?.id && !token?.sub) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const userId = (token.id ?? token.sub)!;

  const pets = await prisma.pet.findMany({
    where: { ownerId: userId },
    include: { gallery: true, healthEvents: true, streaks: true },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ pets });
}

export async function POST(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token?.id && !token?.sub) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const userId = (token.id ?? token.sub)!;

  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const { name, species, breed, sex, dob, notes, avatarUrl } = body as {
    name: string;
    species: string;
    breed?: string;
    sex?: string;
    dob?: string;
    notes?: string;
    avatarUrl?: string;
  };

  if (!name || !species) {
    return NextResponse.json({ error: "name & species required" }, { status: 400 });
  }

  const pet = await prisma.pet.create({
    data: {
      ownerId: userId,
      name,
      species,
      breed: breed ?? null,
      sex: sex ?? null,
      dob: dob ? new Date(dob) : null,
      notes: notes ?? null,
      avatarUrl: avatarUrl ?? null,
    },
  });

  return NextResponse.json({ pet }, { status: 201 });
}
