import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { productId } = await req.json();
  const product = await prisma.product.findUnique({ where: { id: productId } });
  if (!product)
    return NextResponse.json({ error: "Product not found" }, { status: 404 });

  const existing = await prisma.recommendationProfile.findUnique({
    where: { userId: session.user.id },
  });

  const prefs = (existing?.preferences as Record<string, number>) || {};
  const key = product.category ?? "uncategorized";

  await prisma.recommendationProfile.upsert({
    where: { userId: session.user.id },
    update: {
      preferences: { ...prefs, [key]: (prefs[key] ?? 0) + 1 },
      history: existing?.history ?? { orders: [productId] },
    },
    create: {
      userId: session.user.id,
      preferences: { [key]: 1 },
      history: { orders: [productId] },
    },
  });

  await prisma.cartItem.create({
    data: { userId: session.user.id, productId, quantity: 1 },
  });

  return NextResponse.json({ success: true });
}
