// app/api/cart/route.ts
import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getToken } from "next-auth/jwt";

// GET - fetch user’s cart
export async function GET(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const cart = await prisma.cartItem.findMany({
    where: { userId: token.id },
    include: { product: true },
  });

  return NextResponse.json(cart);
}

// POST - add item to cart
export async function POST(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { productId, quantity } = await req.json();

  const cartItem = await prisma.cartItem.upsert({
    where: { userId_productId: { userId: token.id, productId } },
    update: { quantity: { increment: quantity ?? 1 } },
    create: { userId: token.id, productId, quantity: quantity ?? 1 },
  });

  return NextResponse.json(cartItem);
}

// DELETE - remove item from cart
export async function DELETE(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { productId } = await req.json();
  await prisma.cartItem.delete({
    where: { userId_productId: { userId: token.id, productId } },
  });

  return NextResponse.json({ ok: true });
}
