// app/api/cart/suggestions/route.ts
import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getToken } from "next-auth/jwt";

// AI suggestion: based on buyer's cart + past orders
export async function GET(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  // Fetch recent cart + orders
  const cartItems = await prisma.cartItem.findMany({
    where: { userId: token.id },
    include: { product: true },
  });
  const orders = await prisma.order.findMany({
    where: { userId: token.id },
    include: { items: { include: { product: true } } },
  });

  // Very simple AI-like logic (can be upgraded later with embeddings/ML):
  const categories = [
    ...cartItems.map(c => c.product.category),
    ...orders.flatMap(o => o.items.map(i => i.product.category)),
  ].filter(Boolean);

  const mostCommonCategory = categories.sort((a, b) =>
    categories.filter(v => v === a).length - categories.filter(v => v === b).length
  ).pop();

  const suggestions = await prisma.product.findMany({
    where: { category: mostCommonCategory, NOT: { sellerId: token.id } },
    take: 5,
  });

  return NextResponse.json(suggestions);
}
