// app/api/cart/checkout/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import prisma from "@/lib/prisma";

type CheckoutItem = { productId: string; quantity: number };

export async function POST(req: NextRequest) {
  try {
    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
    if (!token?.sub) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const items: CheckoutItem[] = Array.isArray(body.items) ? body.items : [];

    if (!items.length) return NextResponse.json({ error: "No items" }, { status: 400 });

    let total = 0;
    const priceMap: Record<string, number> = {};

    // fetch products and compute total
    for (const it of items) {
      const p = await prisma.product.findUnique({ where: { id: it.productId } });
      if (!p) return NextResponse.json({ error: `Product ${it.productId} not found` }, { status: 404 });
      const qty = Number(it.quantity) || 1;
      total += p.price * qty;
      priceMap[it.productId] = p.price;
    }

    // create order with nested order items (use product connect)
    const order = await prisma.order.create({
      data: {
        userId: token.sub,
        amount: total,
        status: "created",
        items: {
          create: items.map((it) => ({
            productId: it.productId,
            quantity: it.quantity,
            price: priceMap[it.productId],
          })),
        },
      },
      include: { items: true },
    });

    // create payment record (provider order id will be added after Razorpay order creation)
    const payment = await prisma.payment.create({
      data: {
        userId: token.sub,
        orderId: order.id,
        provider: "razorpay",
        providerOrderId: null,
        providerPaymentId: null,
        status: "pending",
        amount: total,
      },
    });

    // clear cart
    await prisma.cartItem.deleteMany({ where: { userId: token.sub } });

    return NextResponse.json({ ok: true, orderId: order.id, paymentId: payment.id });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
