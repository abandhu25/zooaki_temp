import { NextRequest, NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import prisma from "@/lib/prisma";

export async function GET(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token?.sub) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  // verify seller role (simplified)
  const sellerProducts = await prisma.product.findMany({ where: { sellerId: token.sub } });
  const productIds = sellerProducts.map(p => p.id);

  const sales = await prisma.orderItem.aggregate({
    _sum: { price: true },
    where: { productId: { in: productIds } },
  });

  const totalOrders = await prisma.orderItem.count({ where: { productId: { in: productIds } } });

  return NextResponse.json({
    totalSales: sales._sum.price || 0,
    totalOrders,
    topProducts: sellerProducts.slice(0, 5),
  });
}
