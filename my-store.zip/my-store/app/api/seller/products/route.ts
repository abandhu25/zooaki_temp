// app/seller/products/route.ts
import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getToken } from "next-auth/jwt";

export async function POST(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();

  // Only pick what you actually use:
  const data = {
    title: body.title,
    description: body.description ?? null,
    price: Number(body.price),
    stock: Number(body.stock),
    category: body.category ?? null,
    imageUrl: body.imageUrl ?? null,
    sellerId: token.id as string,
    // qCommerce must exist in your Prisma schema as a boolean if you want to set it:
    ...(typeof body.qCommerce === "boolean" ? { qCommerce: body.qCommerce } : {}),
  };

  const created = await prisma.product.create({ data });

  // (Optional) audit log here…

  return NextResponse.json(created);
}
