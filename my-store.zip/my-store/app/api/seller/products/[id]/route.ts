import { NextResponse, type NextRequest } from "next/server";
import prisma from "@/lib/prisma";

export async function PUT(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;

  const {
    title,
    description,
    price,
    stock,
    category,
    imageUrl,
    qCommerce,
  } = body as {
    title?: string;
    description?: string | null;
    price?: number;
    stock?: number;
    category?: string | null;
    imageUrl?: string | null;
    qCommerce?: boolean;
  };

  try {
    const updated = await prisma.product.update({
      where: { id },
      data: {
        ...(title !== undefined ? { title } : {}),
        ...(description !== undefined ? { description } : {}),
        ...(price !== undefined ? { price: Math.round(price) } : {}),
        ...(stock !== undefined ? { stock } : {}),
        ...(category !== undefined ? { category } : {}),
        ...(imageUrl !== undefined ? { imageUrl } : {}),
        ...(qCommerce !== undefined ? { qCommerce } : {}),
      },
    });

    return NextResponse.json(updated);
  } catch (e) {
    console.error("Product update error:", e);
    return NextResponse.json({ error: "Product not found" }, { status: 404 });
  }
}
