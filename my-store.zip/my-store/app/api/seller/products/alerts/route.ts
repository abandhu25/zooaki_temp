// app/api/seller/products/alerts/route.ts
import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getToken } from "next-auth/jwt";

export async function GET(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token?.id || !token.roles?.includes("seller")) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const lowStock = await prisma.product.findMany({
    where: { sellerId: token.id, stock: { lte: 5 } }, // AI trigger: low stock threshold
  });

  return NextResponse.json(lowStock);
}
