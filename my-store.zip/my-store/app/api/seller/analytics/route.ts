import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { hasPower } from "@/lib/acl";

export async function GET() {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const isFounder = hasPower(session, "FOUNDER_ONLY");
  const sellerId = isFounder ? undefined : session.user.id;

  try {
    // ✅ Adapted to your Prisma Order model (no products or sellerId field)
    const orders = await prisma.order.findMany({
      where: sellerId ? { userId: sellerId } : {}, // Filter by userId instead
    });

    // ✅ Use your schema's correct field name: "amount"
    const totalSales = orders.reduce((acc, o) => acc + o.amount, 0);
    const avgOrderValue = orders.length ? totalSales / orders.length : 0;
    const totalOrders = orders.length;

    // Group sales by month
    const monthlySales = orders.reduce((map, order) => {
      const month = order.createdAt.toLocaleString("default", { month: "short" });
      map[month] = (map[month] || 0) + order.amount;
      return map;
    }, {} as Record<string, number>);

    const data = {
      totalSales,
      avgOrderValue,
      totalOrders,
      monthlySales,
    };

    return NextResponse.json({ ok: true, data });
  } catch (err) {
    console.error("Analytics error:", err);
    return NextResponse.json({ error: "Failed to fetch analytics" }, { status: 500 });
  }
}
