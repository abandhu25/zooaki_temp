"use client";
import { useEffect, useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface Product {
  id: string;
  title: string;
  stock: number;
  price: number;
}

export default function SellerDashboard() {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    fetch("/api/seller/products")
      .then((res) => res.json())
      .then(setProducts);
  }, []);

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-bold">Seller Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>My Products</CardTitle>
          </CardHeader>
          <CardContent>
            <p>You have {products.length} active products</p>
            <Button className="mt-3">Manage Products</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Check new orders</p>
            <Button className="mt-3" variant="outline">View Orders</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <p>$2,340 this week</p>
          </CardContent>
        </Card>
      </div>

      {products.some((p) => p.stock < 5) && (
        <div className="bg-red-100 p-4 rounded mt-6">
          <h2 className="font-bold">Low Stock Alerts</h2>
          <ul>
            {products.filter((p) => p.stock < 5).map((p) => (
              <li key={p.id}>{p.title} - Only {p.stock} left!</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
