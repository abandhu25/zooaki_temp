import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import type { Pet } from "@prisma/client";
import { runPetReminders } from "@/lib/ai/petReminder";
/**
 * Daily notification job:
 * - Pet birthdays
 * - Upcoming vet visits
 * - Upcoming health events (e.g., vaccine reminders)
 */
export async function GET() {
  try {
    await runPetReminders();
    return NextResponse.json({ success: true });
  } catch (e) {
  const message = e instanceof Error ? e.message : "Unknown error";
  return NextResponse.json({ error: message }, { status: 500 });
}
}

export async function POST() {
  const now = new Date();
  const month = now.getUTCMonth() + 1;
  const day = now.getUTCDate();

  // 🎂 Birthday wishes
  const pets = await prisma.pet.findMany({ where: { dob: { not: null } } });
  const birthdayPets: Pet[] = pets.filter((p: Pet) => {
    if (!p.dob) return false;
    const d = new Date(p.dob);
    return (d.getUTCMonth() + 1) === month && d.getUTCDate() === day;
  });

  if (birthdayPets.length) {
    await prisma.notification.createMany({
      data: birthdayPets.map((p) => ({
        userId: p.ownerId,
        type: "PET_BIRTHDAY",
        message: `🎉 It’s ${p.name}’s birthday today! Give them some extra love.`,
      })),
    });
  }

  // 💉 Upcoming vaccines / checkups (next 7 days)
  const upcomingHealth = await prisma.petHealthEvent.findMany({
    where: {
      date: {
        gte: now,
        lte: new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000),
      },
    },
    include: { pet: true },
  });

  if (upcomingHealth.length) {
    await prisma.notification.createMany({
      data: upcomingHealth.map((e) => ({
        userId: e.pet.ownerId,
        type: "HEALTH_REMINDER",
        message: `💉 ${e.pet.name} has a ${e.kind.toLowerCase()} due on ${e.date.toDateString()}.`,
      })),
    });
  }

  // 📸 Streak reminder at noon UTC
  const currentHourUTC = now.getUTCHours();
  if (currentHourUTC === 12) {
    const owners = await prisma.user.findMany({
      where: { pets: { some: {} } },
      select: { id: true, name: true },
    });

    await prisma.notification.createMany({
      data: owners.map((u) => ({
        userId: u.id,
        type: "STREAK_REMINDER",
        message: `🐾 Don’t forget today’s Pet Streak! Snap your buddy’s photo 📸`,
      })),
    });
  }

  return NextResponse.json({
    ok: true,
    birthdays: birthdayPets.length,
    healthReminders: upcomingHealth.length,
  });
}
