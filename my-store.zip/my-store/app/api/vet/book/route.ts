import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getToken } from "next-auth/jwt";

export async function POST(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { petId, clinicName, doctorName, visitDate, reason, amount } = await req.json();

  const visit = await prisma.vetVisit.create({
    data: {
      petId,
      clinicName,
      doctorName,
      visitDate: new Date(visitDate),
      reason,
    },
  });

  await prisma.payment.create({
    data: {
      userId: token.id,
      amount,
      status: "pending",
      provider: "razorpay",
    },
  });

  return NextResponse.json({
    visit,
    message: `Vet visit for ${doctorName} scheduled and payment initiated.`,
  });
}
