// app/api/paymentOrder/route.ts
import { NextRequest, NextResponse } from "next/server";
import { createPaymentOrder, updatePaymentStatus } from "@/lib/paymentClient";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { userId, orderId, amount, action, providerPaymentId, status } = body;

    if (action === "create") {
      if (!userId || !orderId || !amount) {
        return NextResponse.json({ error: "Missing parameters" }, { status: 400 });
      }

      const { payment, paymentOrder } = await createPaymentOrder(userId, orderId, amount);
      return NextResponse.json({ payment, paymentOrder });
    }

    if (action === "update") {
      if (!providerPaymentId || !status) {
        return NextResponse.json({ error: "Missing parameters for update" }, { status: 400 });
      }

      const updatedPayment = await updatePaymentStatus(providerPaymentId, status);
      return NextResponse.json({ updatedPayment });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (err) {
    console.error("Payment API error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
