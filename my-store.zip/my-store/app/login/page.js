// app/login/page.js
"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState(""); // for admin 2FA
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const router = useRouter();

  // show OTP field only when admin email is entered (optional UX)
  const isAdminEmail = email.trim().toLowerCase() === "admin@test.com";

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    // call NextAuth credentials provider (no redirect here)
    const res = await signIn("credentials", {
      redirect: false,
      email: email.trim(),
      password,
      otp: isAdminEmail ? otp.trim() : undefined, // include OTP if admin
    });

    setLoading(false);

    if (res?.error) {
      setError(res.error || "Login failed");
      return;
    }

    // SUCCESS: push to homepage — homepage will inspect session and route to proper dashboard
    router.push("/");
  };

  return (
    <div style={{ maxWidth: 420, margin: "60px auto", padding: 20 }}>
      <h2>Sign in</h2>
      <form onSubmit={handleLogin}>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          style={{ display: "block", margin: "10px 0", padding: 8, width: "100%" }}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          style={{ display: "block", margin: "10px 0", padding: 8, width: "100%" }}
        />

        {isAdminEmail && (
          <>
            <div style={{ fontSize: 13, color: "#555" }}>Admin detected — enter 2FA code</div>
            <input
              type="text"
              placeholder="6-digit code"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              required
              style={{ display: "block", margin: "8px 0 16px", padding: 8, width: "100%" }}
            />
          </>
        )}

        <button type="submit" disabled={loading} style={{ padding: "10px 16px" }}>
          {loading ? "Signing in..." : "Sign In"}
        </button>
      </form>

      {error && <p style={{ color: "red", marginTop: 12 }}>{error}</p>}
    </div>
  );
}
