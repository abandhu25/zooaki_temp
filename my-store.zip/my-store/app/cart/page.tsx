"use client";
import { useEffect, useState } from "react";

interface Product {
  id: string;
  title: string;
  price: number;
}

interface CartItem {
  id: string;
  userId: string;
  productId: string;
  quantity: number;
  createdAt: string;
  product: Product; // ✅ fix: include relation
}

export default function CartPage() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [suggestions, setSuggestions] = useState<Product[]>([]);

  useEffect(() => {
    fetch("/api/cart")
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setCart(data);
        } else {
          setCart(data.cart || []);
          setSuggestions(data.suggestions || []);
        }
      });
  }, []);

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-bold">Your Cart</h1>

      {cart.length === 0 ? (
        <p>Your cart is empty</p>
      ) : (
        <div className="space-y-3">
          {cart.map((item) => (
            <div key={item.id} className="p-2 border-b">
              <p className="font-medium">{item.product.title}</p>
              <p className="text-sm text-gray-600">Qty: {item.quantity}</p>
            </div>
          ))}
        </div>
      )}

      {suggestions.length > 0 && (
        <div className="mt-6">
          <h2 className="text-xl font-semibold">You may also like</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-3">
            {suggestions.map((p) => (
              <div key={p.id} className="border p-2 rounded shadow-sm">
                <h3 className="font-medium">{p.title}</h3>
                <p className="text-sm text-gray-700">${p.price}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
