// app/page.tsx
"use client";

import { useEffect } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function Home() {
  const { data: session, status } = useSession();
  const router = useRouter();

  useEffect(() => {
    if (status === "authenticated" && session?.user) {
      const role = session.user.activeRole || session.user.roles?.[0];

      if (role === "buyer") router.push("/buyer/dashboard");
      else if (role === "seller") router.push("/seller/dashboard");
      else if (role === "worker") router.push("/worker/dashboard");
      else if (role === "admin") router.push("/admin/dashboard");
      else router.push("/login");
    }
  }, [status, session, router]);

  if (status === "loading") return <p>Loading...</p>;

  return (
    <div className="flex items-center justify-center h-screen">
      <p>Please log in to continue.</p>
    </div>
  );
}
