/* eslint-disable @next/next/no-img-element */
"use client";

import { useEffect, useState } from "react";

type Product = {
  id: string;
  title: string;
  description?: string;
  price: number;
  stock?: number;
  category?: string;
  imageUrl?: string;
};

export default function SellerDashboard() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);

  // form
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState<number | "">("");
  const [stock, setStock] = useState<number | "">("");
  const [imageUrl, setImageUrl] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  async function fetchProducts() {
    setLoading(true);
    const res = await fetch("/api/seller/products");
    const data = await res.json();
    setProducts(data || []);
    setLoading(false);
  }

  useEffect(() => {
    fetchProducts();
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMessage(null);

    const body = {
      title,
      description,
      price: typeof price === "number" ? price : Number(price),
      stock: typeof stock === "number" ? stock : Number(stock || 0),
      imageUrl: imageUrl || undefined,
    };

    try {
      let res;
      if (editingId) {
        res = await fetch(`/api/seller/products/${editingId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
      } else {
        res = await fetch("/api/seller/products", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
      }
      const data = await res.json();
      if (!res.ok) {
        setMessage(data.error?.message || JSON.stringify(data.error) || "Failed");
        return;
      }
      setMessage(editingId ? "Updated" : "Created");
      setTitle("");
      setDescription("");
      setPrice("");
      setStock("");
      setImageUrl("");
      setEditingId(null);
      fetchProducts();
    } catch (err) {
      console.error(err);
      setMessage("Network error");
    }
  }

  async function handleEdit(p: Product) {
    setEditingId(p.id);
    setTitle(p.title);
    setDescription(p.description || "");
    setPrice(p.price);
    setStock(p.stock ?? 0);
    setImageUrl(p.imageUrl || "");
  }

  async function handleDelete(id: string) {
    if (!confirm("Delete this product?")) return;
    const res = await fetch(`/api/seller/products/${id}`, { method: "DELETE" });
    if (res.ok) fetchProducts();
  }

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-bold">Seller Dashboard</h1>

      <section className="max-w-2xl">
        <h2 className="font-semibold mb-2">{editingId ? "Edit Product" : "Add Product"}</h2>
        {message && <div className="text-sm text-red-600 mb-2">{message}</div>}

        <form onSubmit={handleSubmit} className="space-y-2">
          <input required value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Title" className="w-full p-2 border rounded"/>
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description" className="w-full p-2 border rounded" />
          <input required value={price} onChange={(e) => setPrice(e.target.value === "" ? "" : Number(e.target.value))} placeholder="Price (in paise) e.g. 19900" className="w-full p-2 border rounded" />
          <input value={stock} onChange={(e) => setStock(e.target.value === "" ? "" : Number(e.target.value))} placeholder="Stock" className="w-full p-2 border rounded" />
          <input value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} placeholder="Image URL (or later use upload flow)" className="w-full p-2 border rounded" />
          <div className="flex gap-2">
            <button type="submit" className="bg-green-600 text-white px-3 py-1 rounded">{editingId ? "Update" : "Create"}</button>
            {editingId && <button type="button" onClick={() => { setEditingId(null); setTitle(""); setDescription(""); setPrice(""); setStock(""); setImageUrl(""); }} className="px-3 py-1 border rounded">Cancel</button>}
          </div>
        </form>
      </section>

      <section>
        <h2 className="font-semibold">Your Products</h2>
        {loading ? <p>Loading…</p> :
          <div className="grid grid-cols-3 gap-4 mt-2">
            {products.map(p => (
              <div key={p.id} className="border p-2 rounded">
                {p.imageUrl ? <img src={p.imageUrl} alt={p.title} className="h-28 w-full object-cover mb-2" /> : <div className="h-28 bg-gray-100 mb-2 flex items-center justify-center">No image</div>}
                <div className="font-semibold">{p.title}</div>
                <div>₹{Math.round(p.price / 100)}</div>
                <div className="flex gap-2 mt-2">
                  <button onClick={() => handleEdit(p)} className="text-sm px-2 py-1 border rounded">Edit</button>
                  <button onClick={() => handleDelete(p.id)} className="text-sm px-2 py-1 border rounded text-red-600">Delete</button>
                </div>
              </div>
            ))}
          </div>
        }
      </section>
    </div>
  );
}
