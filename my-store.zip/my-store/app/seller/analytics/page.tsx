"use client";
import { useEffect, useState } from "react";

interface AnalyticsData {
  id: string;
  title: string;
  totalRevenue: number;
  totalOrders: number;
  productsSold: number;
}

export default function AnalyticsPage() {
  const [data, setData] = useState<AnalyticsData[]>([]);

  useEffect(() => {
    fetch("/api/seller/analytics")
      .then((res) => res.json())
      .then(setData);
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Analytics</h1>
      <table className="w-full mt-4 border">
        <thead>
          <tr className="bg-gray-100">
            <th className="p-2 border">Product</th>
            <th className="p-2 border">Orders</th>
            <th className="p-2 border">Sold</th>
            <th className="p-2 border">Revenue</th>
          </tr>
        </thead>
        <tbody>
          {data.map((d) => (
            <tr key={d.id}>
              <td className="p-2 border">{d.title}</td>
              <td className="p-2 border">{d.totalOrders}</td>
              <td className="p-2 border">{d.productsSold}</td>
              <td className="p-2 border">${d.totalRevenue}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
