"use client";

import React, { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { generateAIInsight } from "@/lib/ai/insights";
import SellerChart from "@/components/SellerChart";
import AnalyticsCard from "@/components/AnalyticsCard";

type Metrics = {
  totalSales: number;
  avgOrderValue: number;
  totalOrders: number;
  monthlySales: Record<string, number>;
};

export default function SellerDashboard() {
  const { data: session } = useSession();
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [insight, setInsight] = useState<string>("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
  if (!session?.user) return;
  const fetchData = async () => {
    const res = await fetch("/api/seller/analytics");
    const data = await res.json();
    if (data.ok) {
      setMetrics(data.data);
      const ai = generateAIInsight(data.data);
      setInsight(ai.summary + " " + ai.advice);
    }
    setLoading(false);
  };
  fetchData();
}, [session?.user]);


  if (!session) return <p>Loading session...</p>;
  if (loading) return <p>Loading analytics...</p>;
  if (!metrics) return <p>No analytics found.</p>;

  const { totalSales, avgOrderValue, totalOrders, monthlySales } = metrics;

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-semibold">
        Welcome, {session.user.name || "Seller"}
      </h1>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <AnalyticsCard title="Total Sales" value={`₹${totalSales.toLocaleString()}`} />
        <AnalyticsCard title="Average Order" value={`₹${avgOrderValue.toFixed(2)}`} />
        <AnalyticsCard title="Total Orders" value={totalOrders.toString()} />
      </div>

      <SellerChart data={monthlySales} />

      <section className="border rounded-lg p-4 bg-gray-50 dark:bg-gray-800">
        <h2 className="text-lg font-medium mb-2">AI Insights</h2>
        <p className="text-sm text-muted-foreground">{insight}</p>
      </section>
    </div>
  );
}