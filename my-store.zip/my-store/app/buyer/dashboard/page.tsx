// /app/buyer/dashboard/page.tsx
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getBuyerFeatureMap, FEATURE_KEYS } from "@/lib/features";
import FeatureGate from "@/components/FeatureGate";
import { getBuyerIntents } from "@/lib/ai/intent";
import { getSmartRecommendations } from "@/lib/ai/recommendations";
import BuyerRecommendations from "@/components/BuyerRecommendations";
import Link from "next/link";

export default async function BuyerDashboardPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return (
      <div className="p-6">
        <h1 className="text-xl font-semibold">Please sign in</h1>
      </div>
    );
  }

  // ✅ Fetch all feature toggles
  const features = await getBuyerFeatureMap();
  const intents = await getBuyerIntents(session);

  // ✅ Get smart recommendations (AI layer)
  const recs = await getSmartRecommendations(session.user.id);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Welcome back, {session.user.name ?? "Buyer"}</h1>
        <div className="text-sm text-muted-foreground">
          Active role:{" "}
          <span className="font-medium">
            {session.user.activeRole ?? session.user.roles?.[0] ?? "buyer"}
          </span>
        </div>
      </div>

      {/* AI Intent Suggestions */}
      <section className="rounded-xl border p-4">
        <h2 className="text-lg font-medium mb-3">Smart Suggestions</h2>
        <div className="flex flex-wrap gap-2">
          {intents.map((i, idx) => (
            <span
              key={idx}
              className="inline-flex items-center rounded-full border px-3 py-1 text-sm hover:bg-accent cursor-pointer"
              title={i.type}
            >
              {i.label}
            </span>
          ))}
        </div>
      </section>

      {/* Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* ✅ New: AI Recommendations integrated */}
        <FeatureGate enabled={features[FEATURE_KEYS.RECOMMENDATIONS]}>
          <section className="rounded-xl border p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold">Recommended for You</h3>
              <Link href="/buyer/recommendations" className="text-sm underline">
                See all
              </Link>
            </div>
            <BuyerRecommendations serverData={recs} />
          </section>
        </FeatureGate>

        {/* Pet Feed */}
        <FeatureGate enabled={features[FEATURE_KEYS.PET_FEED]}>
          <section className="rounded-xl border p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold">Your Pet Feed</h3>
              <Link href="/pets" className="text-sm underline">
                Manage pets
              </Link>
            </div>
            <div className="space-y-2 text-sm">
              <div>• Daily streak reminders</div>
              <div>• Vet appointments & vaccination logs</div>
              <div>• Birthday & milestones</div>
            </div>
          </section>
        </FeatureGate>

        {/* Orders summary */}
        <FeatureGate enabled={features[FEATURE_KEYS.ORDERS_SUMMARY]}>
          <section className="rounded-xl border p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold">Orders & Payment</h3>
              <Link href="/buyer/orders" className="text-sm underline">
                View
              </Link>
            </div>
            <div className="text-sm text-muted-foreground">
              Recent orders, delivery ETA, Razorpay statuses.
            </div>
          </section>
        </FeatureGate>

        {/* Subscription */}
        <FeatureGate enabled={features[FEATURE_KEYS.SUBSCRIPTION]}>
          <section className="rounded-xl border p-4 lg:col-span-2">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold">ZooAki Plus</h3>
              <Link href="/buyer/subscription" className="text-sm underline">
                Manage
              </Link>
            </div>
            <div className="text-sm text-muted-foreground">
              Internet-included subscription, cost optimization, auto-savings.
            </div>
          </section>
        </FeatureGate>

        {/* Q-Commerce toggle */}
        <FeatureGate enabled={features[FEATURE_KEYS.QCOMMERCE_TOGGLE]}>
          <section className="rounded-xl border p-4">
            <h3 className="font-semibold mb-3">Instant Delivery</h3>
            <div className="text-sm text-muted-foreground">
              Toggle fast delivery for your next orders.
            </div>
          </section>
        </FeatureGate>

        {/* Gallery shortcut */}
        <FeatureGate enabled={features[FEATURE_KEYS.GALLERY]}>
          <section className="rounded-xl border p-4">
            <h3 className="font-semibold mb-3">Pet Gallery</h3>
            <div className="text-sm text-muted-foreground">
              Upload photos, auto-add to feed, AI-import from device gallery (when supported).
            </div>
          </section>
        </FeatureGate>
      </div>

      {/* Admin shortcut */}
      {(session.user.roles?.includes("ADMIN") ||
        session.user.roles?.includes("SUPERADMIN")) && (
        <div className="text-xs text-muted-foreground">
          Admin? Go to{" "}
          <Link href="/admin/dashboard" className="underline">
            Admin Dashboard
          </Link>{" "}
          to toggle features.
        </div>
      )}
    </div>
  );
}
