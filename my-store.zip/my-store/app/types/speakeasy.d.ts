declare module "speakeasy";
