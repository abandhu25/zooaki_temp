// middleware.ts
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { getToken } from "next-auth/jwt";
import prisma from "@/lib/prisma";
import { adminControlMiddleware } from "@/middleware/adminControl";

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // 1️⃣ Allow static and auth routes freely
  if (
    pathname.startsWith("/_next") ||
    pathname.startsWith("/api") ||
    pathname.startsWith("/auth") ||
    pathname === "/"
  ) {
    return NextResponse.next();
  }

  // 2️⃣ Run Admin Control check (block routes)
  const adminResponse = await adminControlMiddleware(req);
  if (adminResponse?.status === 403) return adminResponse;

  // 3️⃣ Check FeatureControl toggles
  const feature = await prisma.featureControl.findUnique({
    where: { route: pathname },
  });
  if (feature && !feature.isEnabled) {
    return NextResponse.redirect(new URL("/coming-soon", req.url));
  }

  // 4️⃣ Check authentication
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token) {
    return NextResponse.redirect(new URL("/auth/signin", req.url));
  }

  // 5️⃣ Role-based home redirection
  const role = token.activeRole || token.roles?.[0];
  if (pathname === "/") {
    const roleRedirects: Record<string, string> = {
      buyer: "/buyer",
      seller: "/seller",
      worker: "/worker",
      admin: "/admin",
    };
    const destination = roleRedirects[role as keyof typeof roleRedirects] || "/auth/signin";
    return NextResponse.redirect(new URL(destination, req.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/api/:path*", "/admin/:path*", "/seller/:path*", "/buyer/:path*"],
};
