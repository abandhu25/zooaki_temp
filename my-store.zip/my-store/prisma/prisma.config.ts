import path from "node:path";
import * as dotenv from "dotenv";

// 👇 force load your .env at project root
dotenv.config({ path: path.resolve(process.cwd(), ".env") });

const prismaConfig = {
  schema: path.join("prisma", "schema.prisma"),
  migrations: {
    path: path.join("prisma", "migrations"),
    seed: "tsx prisma/seed.ts", // Adjust if your seed file path differs
  },
};

export default prismaConfig;
