/*
  Warnings:

  - A unique constraint covering the columns `[route]` on the table `FeatureControl` will be added. If there are existing duplicate values, this will fail.
  - Made the column `route` on table `FeatureControl` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE "public"."FeatureControl" ALTER COLUMN "route" SET NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "FeatureControl_route_key" ON "public"."FeatureControl"("route");
