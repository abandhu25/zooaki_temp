-- AlterTable
ALTER TABLE "public"."FeatureControl" ALTER COLUMN "route" DROP NOT NULL;
