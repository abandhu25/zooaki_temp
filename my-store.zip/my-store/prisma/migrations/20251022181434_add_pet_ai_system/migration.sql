-- CreateIndex
CREATE INDEX "Pet_ownerId_idx" ON "public"."Pet"("ownerId");

-- CreateIndex
CREATE INDEX "PetFeed_petId_idx" ON "public"."PetFeed"("petId");

-- CreateIndex
CREATE INDEX "PetStreak_petId_idx" ON "public"."PetStreak"("petId");

-- CreateIndex
CREATE INDEX "PregnancyRecord_petId_idx" ON "public"."PregnancyRecord"("petId");

-- CreateIndex
CREATE INDEX "VetVisit_petId_idx" ON "public"."VetVisit"("petId");
