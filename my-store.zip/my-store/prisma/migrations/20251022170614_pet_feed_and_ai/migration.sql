-- CreateTable
CREATE TABLE "public"."PetFeed" (
    "id" TEXT NOT NULL,
    "petId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "content" TEXT,
    "mediaUrl" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "PetFeed_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "public"."PetFeed" ADD CONSTRAINT "PetFeed_petId_fkey" FOREIGN KEY ("petId") REFERENCES "public"."Pet"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
