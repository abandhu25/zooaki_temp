-- AlterTable
ALTER TABLE "public"."Notification" ADD COLUMN     "metadata" JSONB;

-- CreateTable
CREATE TABLE "public"."PetInsight" (
    "id" TEXT NOT NULL,
    "petId" TEXT NOT NULL,
    "mood" TEXT,
    "healthTip" TEXT,
    "detectedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "aiMeta" JSONB,

    CONSTRAINT "PetInsight_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "public"."PetInsight" ADD CONSTRAINT "PetInsight_petId_fkey" FOREIGN KEY ("petId") REFERENCES "public"."Pet"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
