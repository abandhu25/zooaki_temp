/*
  Warnings:

  - You are about to drop the column `interests` on the `RecommendationProfile` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "public"."Product" ADD COLUMN     "aiDesc" TEXT,
ADD COLUMN     "qCommerce" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "public"."RecommendationProfile" DROP COLUMN "interests";
