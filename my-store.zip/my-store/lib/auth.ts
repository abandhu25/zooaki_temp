// lib/auth.ts
import type { NextAuthOptions, Session, User } from "next-auth";
import type { AdapterUser } from "next-auth/adapters";
import type { JWT } from "next-auth/jwt";
import GoogleProvider from "next-auth/providers/google";
import CredentialsProvider from "next-auth/providers/credentials";
import prisma from "@/lib/prisma";
import bcrypt from "bcryptjs";

/**
 * This type ensures roles are always an array, not optional.
 * We extend AdapterUser and make sure emailVerified exists.
 */
type ZooakiUser = AdapterUser & {
  roles: string[];
  activeRole: string | null;
};

export const authOptions: NextAuthOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID ?? "",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? "",
    }),
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials): Promise<ZooakiUser | null> {
        if (!credentials?.email || !credentials.password) return null;

        const dbUser = await prisma.user.findUnique({
          where: { email: credentials.email },
        });
        if (!dbUser) return null;

        const ok = await bcrypt.compare(credentials.password, dbUser.password);
        if (!ok) return null;

        return {
          id: dbUser.id,
          name: dbUser.name,
          email: dbUser.email,
          roles: dbUser.roles ?? [],
          activeRole: dbUser.activeRole ?? null,
          emailVerified: null, // required by AdapterUser
        };
      },
    }),
  ],

  session: { strategy: "jwt" },

  callbacks: {
    async jwt({
      token,
      user,
    }: {
      token: JWT;
      user?: User | AdapterUser | null;
    }): Promise<JWT> {
      if (user) {
        const zooUser = user as ZooakiUser;
        token.id = zooUser.id;
        token.roles = zooUser.roles;
        token.activeRole = zooUser.activeRole;
      }
      return token;
    },

    async session({
      session,
      token,
    }: {
      session: Session;
      token: JWT;
    }): Promise<Session> {
      if (session.user) {
        session.user.id = token.id ?? "";
        session.user.roles = (token.roles ?? []) as string[];
        session.user.activeRole = token.activeRole ?? null;
      }
      return session;
    },
  },

  secret: process.env.NEXTAUTH_SECRET,
};

export default authOptions;
