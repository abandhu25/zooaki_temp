// /lib/features.ts
import prisma from "@/lib/prisma";

// Canonical feature keys used across the app.
// You can add new features without touching dashboard rendering logic.
export const FEATURE_KEYS = {
  RECOMMENDATIONS: "buyer.recommendations",
  PET_FEED: "buyer.petFeed",
  ORDERS_SUMMARY: "buyer.ordersSummary",
  SUBSCRIPTION: "buyer.subscription",
  QCOMMERCE_TOGGLE: "buyer.qCommerceToggle",
  GALLERY: "buyer.gallery",
  // add more here
} as const;

export type FeatureKey = (typeof FEATURE_KEYS)[keyof typeof FEATURE_KEYS];

/** Fetch all feature flags for buyer scope */
export async function getBuyerFeatureMap(): Promise<Record<FeatureKey, boolean>> {
  // Persist features in `featureControl` table with `name` equal to keys above.
  // Fallback to true if not found (safe default), but you can default false if you prefer stricter gating.
  const rows = await prisma.featureControl.findMany({
    where: { name: { in: Object.values(FEATURE_KEYS) } },
  });

  const byName = new Map(rows.map(r => [r.name, r.isEnabled]));
  const map = {} as Record<FeatureKey, boolean>;

  for (const key of Object.values(FEATURE_KEYS)) {
    map[key] = byName.get(key) ?? true; // default enabled
  }

  return map;
}

/** Single check if needed elsewhere */
export async function isFeatureEnabled(key: FeatureKey): Promise<boolean> {
  const row = await prisma.featureControl.findUnique({ where: { name: key } });
  return row?.isEnabled ?? true;
}
