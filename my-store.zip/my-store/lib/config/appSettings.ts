export const appSettings = {
  appName: "ZooAki",
  tagline: "Your trust Our guarantee.",
  enableBeRealMode: true,
  showVetSection: true,
  defaultLanguage: "en",
};
