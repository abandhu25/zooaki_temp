import Razorpay from "razorpay";
import { PrismaClient } from "@prisma/client";
import { PaymentStatus } from "@prisma/client";


const prisma = new PrismaClient();

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

export async function createPaymentOrder(userId: string, orderId: string, amount: number) {
  try {
    const options = {
      amount: amount * 100,
      currency: "INR",
      receipt: orderId,
    };

    const paymentOrder = await razorpay.orders.create(options);

    const payment = await prisma.payment.create({
      data: {
        userId,
        orderId,
        amount,
        status: "created" as PaymentStatus,
        provider: "razorpay",
        providerOrderId: paymentOrder.id, // <-- fixed field name
      },
    });

    return { payment, paymentOrder };
  } catch (err) {
    console.error("Payment creation error:", err);
    throw err;
  }
}

export async function updatePaymentStatus(providerPaymentId: string, status: string) {
return await prisma.payment.updateMany({
  where: { providerOrderId: providerPaymentId }, // ✅ corrected
  data: { status: status as PaymentStatus },
});
}