import { Session } from "next-auth";
import { JWT } from "next-auth/jwt";

type RoleCarrier = {
  roles?: string[];
  user?: { roles?: string[] };
};

/**
 * Checks if the given session/JWT has a required power or role.
 * Works with both Session and JWT tokens.
 */
export function hasPower(session: Session | JWT | RoleCarrier | null | undefined, requiredRole: string): boolean {
  if (!session) return false;

  const roles =
    (session as RoleCarrier).roles ??
    (session as RoleCarrier).user?.roles ??
    [];

  if (!roles.length) return false;

  switch (requiredRole) {
    case "FOUNDER_ONLY":
      return roles.includes("FOUNDER") || roles.includes("SUPERADMIN");
    case "ADMIN_ONLY":
      return roles.includes("ADMIN") || roles.includes("FOUNDER");
    default:
      return roles.includes(requiredRole);
  }
}
