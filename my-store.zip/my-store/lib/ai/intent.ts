// /lib/ai/intent.ts
// This is where we let AI propose “what the customer may want next”
// even if it’s not currently implemented. It should NEVER leak restricted data.

import type { Session } from "next-auth";

type Intent =
  | { type: "BUY_REORDER"; label: string; meta?: Record<string, unknown> }
  | { type: "BOOK_VET"; label: string; meta?: Record<string, unknown> }
  | { type: "PET_DIET_PLAN"; label: string; meta?: Record<string, unknown> }
  | { type: "UPSELL_SUBSCRIPTION"; label: string; meta?: Record<string, unknown> }
  | { type: "COMMUNITY_STREAK"; label: string; meta?: Record<string, unknown> }
  | { type: "UNKNOWN"; label: string; meta?: Record<string, unknown> };

export async function getBuyerIntents(session: Session | null): Promise<Intent[]> {
  // Add heuristics. Keep privacy boundaries:
  // - NO raw payment card data
  // - NO founder-only metrics
  // Use only buyer-owned data + aggregates safe for the buyer.
  const hasPet = !!session?.user?.id; // Replace with real check if user has pets
  const intents: Intent[] = [];

  // Soft examples:
  intents.push({ type: "UPSELL_SUBSCRIPTION", label: "Save on delivery with ZooAki Plus" });

  if (hasPet) {
    intents.push({ type: "COMMUNITY_STREAK", label: "Post today’s BeReal-style pet streak 📸" });
    intents.push({ type: "PET_DIET_PLAN", label: "Get a smart diet plan for your pet" });
    intents.push({ type: "BOOK_VET", label: "Book a veterinary visit in 2 taps" });
  } else {
    intents.push({ type: "BUY_REORDER", label: "Re-order your last viewed item (smart suggestion)" });
  }

  return intents;
}
