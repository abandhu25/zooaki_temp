import OpenAI from "openai";
import prisma from "@/lib/prisma";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

export async function analyzePetAI(petId: string) {
  const pet = await prisma.pet.findUnique({
    where: { id: petId },
    include: { gallery: true, healthEvents: true },
  });

  if (!pet) throw new Error("Pet not found");

  const latestPhoto = pet.gallery[0]?.url || "No recent image";
  const healthSummary = pet.healthEvents.map(e => `${e.kind}: ${e.value}`).join(", ");

  const prompt = `
You are ZooAki, an AI pet behavior expert.
Given this data:
- Pet Name: ${pet.name}
- Species: ${pet.species}
- Health Info: ${healthSummary || "No recent records"}
- Latest Image URL: ${latestPhoto}

Predict the pet's current mood and provide one health or lifestyle tip.
  `;

  const aiResponse = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
  });

  const analysis = aiResponse.choices[0].message.content;

  await prisma.petInsight.create({
  data: {
    petId,
    mood: analysis?.match(/mood:\s*(.*)/i)?.[1] || "Unknown",
    healthTip: analysis || "No tip available",
    aiMeta: { raw: analysis },
  },
});


  return analysis;
}
