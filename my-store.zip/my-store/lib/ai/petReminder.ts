import prisma from "@/lib/prisma";

export async function runPetReminders() {
  const pets = await prisma.pet.findMany({
    include: { owner: true },
  });

  for (const pet of pets) {
    const today = new Date();
    const ageYears = pet.dob ? today.getFullYear() - pet.dob.getFullYear() : null;

    // Birthday reminder 🎂
    if (pet.dob && pet.dob.getDate() === today.getDate() && pet.dob.getMonth() === today.getMonth()) {
      await prisma.notification.create({
        data: {
          userId: pet.ownerId,
          type: "BIRTHDAY",
          message: `🎉 It's ${pet.name}'s birthday! They’re now ${ageYears} years old.`,
        },
      });
    }

    // Pregnancy reminder 🍼
    const pregnant = await prisma.pregnancyRecord.findFirst({
      where: { petId: pet.id, dueDate: { gte: today } },
    });

    if (pregnant) {
      await prisma.notification.create({
        data: {
          userId: pet.ownerId,
          type: "PREGNANCY",
          message: `${pet.name}'s due date is approaching soon! 🐶💖`,
        },
      });
    }
  }
}
