export async function getSmartRecommendations(userId: string) {
  // Generate a personalized "AI seed" based on userId hash
  const hash = Array.from(userId)
    .reduce((acc, char) => acc + char.charCodeAt(0), 0) % 10;

  const baseProducts = [
    { id: 1, name: "Organic Pet Food", score: Math.random() * 10 + hash },
    { id: 2, name: "Pet Tracker Collar", score: Math.random() * 10 + hash / 2 },
    { id: 3, name: "Comfort Bed Deluxe", score: Math.random() * 10 + hash / 3 },
  ];

  const sorted = baseProducts.sort((a, b) => b.score - a.score);
  return sorted.slice(0, 3);
}
