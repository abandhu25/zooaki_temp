type Mood = "excellent" | "low" | "neutral";

export function generateAIInsight(metrics: {
  totalSales: number;
  avgOrderValue: number;
  totalOrders: number;
  monthlySales: Record<string, number>;
}) {
  const { totalSales, avgOrderValue, totalOrders, monthlySales } = metrics;

  const topMonth = Object.entries(monthlySales).sort((a, b) => b[1] - a[1])[0]?.[0];
  const bottomMonth = Object.entries(monthlySales).sort((a, b) => a[1] - b[1])[0]?.[0];

  let mood: Mood = "neutral";
  if (totalSales > 100000) mood = "excellent";
  else if (totalSales < 20000) mood = "low";

  const suggestions: Record<Mood, string> = {
    excellent: "Keep your top sellers in stock — momentum is high!",
    low: "Consider discounts or collaborations to boost visibility.",
    neutral: "Maintain steady ads and community engagement.",
  };

  return {
    summary: `You made ₹${totalSales.toLocaleString()} in total sales across ${totalOrders} orders. Average order value is ₹${avgOrderValue.toFixed(2)}.`,
    topMonth,
    bottomMonth,
    advice: suggestions[mood],
  };
}
