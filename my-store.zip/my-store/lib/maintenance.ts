import prisma from "@/lib/prisma";
import { pusherServer } from "@/lib/pusher";

export async function runMaintenanceTasks() {
  // 1. Clean expired carts
  const expired = await prisma.cartItem.deleteMany({
    where: {
      createdAt: {
        lt: new Date(Date.now() - 1000 * 60 * 60 * 24),
      },
    },
  });

  if (expired.count > 0) {
    await prisma.maintenanceLog.create({
      data: {
        type: "cart_cleanup",
        message: `Removed ${expired.count} expired cart items.`,
      },
    });

    // If you want system-wide notification, pick affected userIds first
    // Example: all users with expired carts (simplified here)
    const users = await prisma.user.findMany({ select: { id: true } });
    for (const u of users) {
      await prisma.notification.create({
        data: {
          userId: u.id,
          type: "system",
          message: "We cleaned up expired items from your cart.",
        },
      });

      await pusherServer.trigger(`user-${u.id}`, "new-notification", {
        message: "We cleaned up expired items from your cart.",
      });
    }
  }

  // 2. DB health
  const productCount = await prisma.product.count();
  if (productCount === 0) {
    await prisma.maintenanceLog.create({
      data: {
        type: "db_check",
        message: "No products found in DB – investigate.",
      },
    });
  }

  // 3. Rotate recommendation timestamps
  await prisma.recommendationProfile.updateMany({
    data: { updatedAt: new Date() },
  });
}
