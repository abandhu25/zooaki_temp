// middleware/adminControl.ts
import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function adminControlMiddleware(req: NextRequest) {
  const path = req.nextUrl.pathname;

  try {
    // ✅ Use lowercase `.adminControl`
    const isBlocked = await prisma.adminControl.findFirst({
      where: {
        targetRoute: path,
        isActive: true,
        actionType: "BLOCK_ROUTE",
      },
    });

    if (isBlocked) {
      return NextResponse.json(
        { error: "This route is currently blocked by admin." },
        { status: 403 }
      );
    }

    return NextResponse.next();
  } catch (error) {
    console.error("Admin control middleware error:", error);
    return NextResponse.next(); // Failsafe
  }
}
